
# yao garbled circuit evaluation v1. simple version based on smart
# naranker dulay, dept of computing, imperial college, october 2018

OBLIVIOUS_TRANSFERS = True

if OBLIVIOUS_TRANSFERS: # __________________________________________________

  # bellare-micali OT with naor and pinkas optimisations, see smart p423

  # << removed >>

else: # ____________________________________________________________________

  # non oblivious transfers, not even a secure channel is used, for testing

  # << removed >>

# __________________________________________________________________________


