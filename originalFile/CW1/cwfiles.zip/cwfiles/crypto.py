
# yao garbled circuit evaluation v1. simple version based on smart
# naranker dulay, dept of computing, imperial college, october 2018

ENCRYPTED = True

if ENCRYPTED: #_____________________________________________________________

  # secure AES based encryption

  # << removed >>

else: # ____________________________________________________________________

  # totally insecure keyless implementation 

  # << removed >>

# __________________________________________________________________________


